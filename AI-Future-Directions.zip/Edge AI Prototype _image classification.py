import pandas as pd

# -----------------------------
# 1. Load the Excel file
# -----------------------------
file_path = r"C:\Users\yolis\Videos\Captures\AI for Software Engineering\Week 6\Cell_Lines_Details.xlsx"

# Load the Excel file
try:
    xls = pd.ExcelFile(file_path)
    print("Excel file loaded successfully!")
except FileNotFoundError:
    print(f"File not found: {file_path}")
    exit()

# -----------------------------
# 2. Check sheet names
# -----------------------------
print("\nSheet names in the Excel file:")
print(xls.sheet_names)

# -----------------------------
# 3. Read the first sheet (or specify sheet_name)
# -----------------------------
sheet_name = xls.sheet_names[0]  # replace with your desired sheet if needed
df = pd.read_excel(file_path, sheet_name=sheet_name)

# -----------------------------
# 4. Explore the data
# -----------------------------
print("\nFirst 5 rows of the data:")
print(df.head())

print("\nData info:")
print(df.info())

print("\nSummary statistics:")
print(df.describe(include='all'))

print("\nMissing values per column:")
print(df.isnull().sum())

# -----------------------------
# 5. Example: Filter or clean data
# -----------------------------
# Example: remove rows with missing 'Cell Line Name' (adjust column name as needed)
if 'Cell Line Name' in df.columns:
    df_clean = df.dropna(subset=['Cell Line Name'])
    print(f"\nRows after removing missing 'Cell Line Name': {df_clean.shape[0]}")
else:
    df_clean = df.copy()

# -----------------------------
# 6. Example: Save a cleaned version
# -----------------------------
output_file = r"C:\Users\yolis\Videos\Captures\AI for Software Engineering\Week 6\Cell_Lines_Details_Cleaned.xlsx"
df_clean.to_excel(output_file, index=False)
print(f"\nCleaned data saved to: {output_file}")

# -----------------------------
# 7. Optional: Prepare for ML (encode categorical columns)
# -----------------------------
# Automatically convert categorical/text columns to numeric codes
df_ml = df_clean.copy()
for col in df_ml.select_dtypes(include='object').columns:
    df_ml[col] = df_ml[col].astype('category').cat.codes

print("\nData prepared for ML (categorical columns encoded):")
print(df_ml.head())
