import pandas as pd
from sklearn.ensemble import RandomForestRegressor

# Sample sensor data
data = pd.DataFrame({
    'soil_moisture': [30, 45, 50, 40],
    'temperature': [25, 27, 26, 28],
    'light_intensity': [200, 220, 210, 230],
    'yield': [1.2, 1.5, 1.3, 1.6]
})

X = data[['soil_moisture', 'temperature', 'light_intensity']]
y = data['yield']

model = RandomForestRegressor()
model.fit(X, y)

# Predict yield for new sensor data
new_data = pd.DataFrame({'soil_moisture':[35], 'temperature':[26], 'light_intensity':[215]})
predicted_yield = model.predict(new_data)
print(f"Predicted Crop Yield: {predicted_yield[0]:.2f} tons/ha")
